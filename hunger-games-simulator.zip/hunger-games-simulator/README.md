# Hunger Games Simulator

## Overview
The Hunger Games Simulator is a Node.js application that allows users to simulate a survival scenario inspired by the Hunger Games series. Players can create up to 200 characters, each with unique gender and personality traits that influence their behavior and interactions throughout the simulation. The simulator includes various actions such as building shelters, crafting tools, and facing ethical dilemmas, all while navigating through global events like sandstorms and volcanic eruptions.

## Features
- **Character Creation**: Create up to 200 characters with customizable names, genders, and personality traits.
- **Aura System**: Characters have an aura that affects their actions and outcomes based on their experiences, both positive and negative.
- **Dynamic Interactions**: Characters can build shelters, craft tools, form alliances, and face moral dilemmas.
- **Global Events**: Random global events can occur, impacting the survival of characters and the overall simulation.
- **Simulation Control**: Start and manage the simulation, progressing through days and observing character interactions and events.

## Getting Started

### Prerequisites
- Node.js (version 14 or higher)
- npm (Node package manager)

### Installation
1. Clone the repository:
   ```
   git clone https://github.com/yourusername/hunger-games-simulator.git
   ```
2. Navigate to the project directory:
   ```
   cd hunger-games-simulator
   ```
3. Install the dependencies:
   ```
   npm install
   ```

### Running the Simulator
To start the simulation, run the following command:
```
node src/index.js
```

### Project Structure
```
hunger-games-simulator
├── src
│   ├── index.js                # Entry point of the application
│   ├── models
│   │   ├── character.js        # Character model
│   │   └── aura.js             # Aura model
│   ├── controllers
│   │   ├── simulationController.js # Simulation logic
│   │   └── eventController.js   # Global events management
│   ├── utils
│   │   ├── traits.js           # Personality traits definitions
│   │   └── globalEvents.js     # Global events definitions
│   └── types
│       └── index.d.ts          # TypeScript definitions
├── package.json                 # npm configuration
└── README.md                    # Project documentation
```

## Contributing
Contributions are welcome! Please feel free to submit a pull request or open an issue for any suggestions or improvements.

## License
This project is licensed under the MIT License. See the LICENSE file for more details.