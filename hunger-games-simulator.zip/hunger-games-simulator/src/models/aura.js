class Aura {
  constructor() {
    this.positiveAura = 0;
    this.negativeAura = 0;
  }

  updateAura(actionOutcome) {
    if (actionOutcome === 'positive') {
      this.positiveAura += 1;
      this.negativeAura = Math.max(0, this.negativeAura - 1); // Decrease negative aura if possible
    } else if (actionOutcome === 'negative') {
      this.negativeAura += 1;
      this.positiveAura = Math.max(0, this.positiveAura - 1); // Decrease positive aura if possible
    }
  }

  getAuraEffect() {
    // Aura effect can influence actions, e.g., higher positive aura increases success rate
    return this.positiveAura - this.negativeAura;
  }
}

export default Aura;