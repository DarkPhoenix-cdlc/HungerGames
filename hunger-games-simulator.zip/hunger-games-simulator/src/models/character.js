class Character {
  constructor(name, gender, traits) {
    this.name = name;
    this.gender = gender;
    this.traits = traits; // Array of personality traits
    this.aura = null; // Will be set to an instance of Aura
    this.alive = true;
    this.shelterBuilt = false;
    this.toolsCrafted = false;
  }

  buildShelter() {
    if (this.alive) {
      this.shelterBuilt = true;
      this.updateAura(1); // Positive action
      return `${this.name} ha construido un refugio.`;
    }
    return `${this.name} no puede construir un refugio porque está muerto.`;
  }

  craftTools() {
    if (this.alive) {
      this.toolsCrafted = true;
      this.updateAura(1); // Positive action
      return `${this.name} ha fabricado herramientas.`;
    }
    return `${this.name} no puede fabricar herramientas porque está muerto.`;
  }

  interactWith(otherCharacter) {
    if (this.alive && otherCharacter.alive) {
      const interactionOutcome = Math.random() < 0.5 ? 'amigable' : 'hostil';
      this.updateAura(interactionOutcome === 'amigable' ? 1 : -1);
      return `${this.name} tuvo un encuentro ${interactionOutcome} con ${otherCharacter.name}.`;
    }
    return `${this.name} no puede interactuar porque uno de ellos está muerto.`;
  }

  updateAura(value) {
    if (!this.aura) {
      this.aura = new Aura();
    }
    this.aura.update(value);
  }
}

export default Character;