const express = require('express');
const bodyParser = require('body-parser');
const { SimulationController } = require('./controllers/simulationController');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

const simulationController = new SimulationController();

app.post('/start-simulation', (req, res) => {
  simulationController.startSimulation(req.body.characters);
  res.status(200).send({ message: 'Simulation started!' });
});

app.get('/simulate-day', (req, res) => {
  const result = simulationController.simulateDay();
  res.status(200).send(result);
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});