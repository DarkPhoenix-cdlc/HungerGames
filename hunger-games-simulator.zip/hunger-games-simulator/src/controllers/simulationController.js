class SimulationController {
  constructor(characters) {
    this.characters = characters;
    this.day = 1;
  }

  startSimulation() {
    console.log("Simulación iniciada.");
    this.simulateDay();
  }

  simulateDay() {
    console.log(`\n🌅 Día ${this.day}`);
    this.characters.forEach(character => {
      this.simulateCharacterActions(character);
    });
    this.triggerGlobalEvent();
    this.day++;
  }

  simulateCharacterActions(character) {
    // Simulate actions based on character traits and aura
    const actions = [
      'construyó un refugio',
      'fabricó una herramienta',
      'interactuó con otro personaje',
      'exploró el área',
      'descansó'
    ];
    
    const action = this.pickRandom(actions);
    console.log(`${character.name} ${action}.`);
    
    // Update aura based on actions
    character.aura.updateAura(action);
  }

  triggerGlobalEvent() {
    // Logic to trigger a random global event
    const globalEvents = [
      "🌪️ Una tormenta de arena azota el área.",
      "🌋 Un volcán entra en erupción.",
      "🔥 Un incendio forestal repentino.",
      "💀 Evento de muerte súbita: alguien muere sin explicación."
    ];
    
    const event = this.pickRandom(globalEvents);
    console.log(event);
    
    // Apply effects of the global event on characters
    this.applyGlobalEventEffects(event);
  }

  applyGlobalEventEffects(event) {
    // Logic to apply effects based on the global event
    if (event.includes("mueren")) {
      this.killRandomCharacters(3);
    }
  }

  killRandomCharacters(n) {
    const aliveCharacters = this.characters.filter(c => c.alive);
    for (let i = 0; i < n && aliveCharacters.length > 0; i++) {
      const victim = this.pickRandom(aliveCharacters);
      if (victim) {
        victim.alive = false;
        console.log(`${victim.name} ha muerto debido a un evento global.`);
      }
    }
  }

  pickRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }
}

export default SimulationController;