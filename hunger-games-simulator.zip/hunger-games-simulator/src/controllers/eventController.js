class EventController {
  constructor(characters) {
    this.characters = characters;
    this.globalEvents = [
      "🌪️ Una tormenta de arena azota el área.",
      "🌋 Un volcán entra en erupción. Algunos mueren.",
      "🔥 Un incendio forestal repentino.",
      "💀 Evento de muerte súbita: alguien muere sin explicación.",
      "🌕 Noche tranquila, todos duermen mal."
    ];
  }

  triggerRandomEvent() {
    const eventChance = Math.random();
    if (eventChance < 0.3) {
      const event = this.pickRandom(this.globalEvents);
      this.applyEvent(event);
    }
  }

  applyEvent(event) {
    console.log(event);
    if (event.includes("mueren")) {
      this.killRandom(3);
    }
    if (event.includes("muerte súbita")) {
      this.killRandom(1);
    }
  }

  killRandom(n) {
    const aliveCharacters = this.characters.filter(c => c.alive);
    for (let i = 0; i < n && aliveCharacters.length > 0; i++) {
      const victim = this.pickRandom(aliveCharacters);
      if (victim) {
        victim.alive = false;
        console.log(`${victim.name} murió por el evento global.`);
      }
    }
  }

  pickRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }
}

export default EventController;