interface Character {
    name: string;
    gender: 'male' | 'female' | 'non-binary';
    traits: Trait[];
    aura: Aura;
    alive: boolean;

    buildShelter(): void;
    craftTool(toolType: string): void;
    interactWith(other: Character): void;
}

interface Aura {
    positive: number;
    negative: number;

    updateAura(outcome: 'positive' | 'negative'): void;
}

type Trait = {
    name: string;
    description: string;
    effect: (character: Character) => void;
};

interface GlobalEvent {
    description: string;
    impact: (characters: Character[]) => void;
}

interface Simulation {
    characters: Character[];
    days: number;

    start(): void;
    simulateDay(): void;
    triggerGlobalEvent(event: GlobalEvent): void;
}