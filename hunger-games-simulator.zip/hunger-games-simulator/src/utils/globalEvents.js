const globalEvents = [
  {
    event: "🌪️ Tormenta de arena",
    description: "Una tormenta de arena azota el área, reduciendo la visibilidad y causando desorientación.",
    effect: (characters) => {
      characters.forEach(character => {
        if (Math.random() < 0.5) {
          character.aura.negative += 1;
          console.log(`${character.name} se siente desorientado por la tormenta.`);
        }
      });
    }
  },
  {
    event: "🌋 Erupción volcánica",
    description: "Un volcán entra en erupción, causando caos y destrucción en la zona.",
    effect: (characters) => {
      const victims = Math.floor(Math.random() * 3) + 1; // 1 to 3 victims
      for (let i = 0; i < victims; i++) {
        const victim = pickRandom(characters);
        if (victim) {
          victim.alive = false;
          console.log(`${victim.name} fue víctima de la erupción volcánica.`);
        }
      }
    }
  },
  {
    event: "🔥 Incendio forestal",
    description: "Un incendio forestal repentino amenaza a todos los personajes en el área.",
    effect: (characters) => {
      characters.forEach(character => {
        if (Math.random() < 0.3) {
          character.alive = false;
          console.log(`${character.name} no logró escapar del incendio.`);
        }
      });
    }
  },
  {
    event: "💧 Lluvias torrenciales",
    description: "Lluvias torrenciales inundan el área, dificultando la búsqueda de recursos.",
    effect: (characters) => {
      characters.forEach(character => {
        character.aura.negative += 1;
        console.log(`${character.name} se siente frustrado por las lluvias.`);
      });
    }
  },
  {
    event: "🌕 Noche tranquila",
    description: "Una noche tranquila permite a los personajes descansar y recuperar energía.",
    effect: (characters) => {
      characters.forEach(character => {
        character.aura.positive += 1;
        console.log(`${character.name} se siente renovado tras una noche tranquila.`);
      });
    }
  }
];

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

export default globalEvents;