export const traits = {
  brave: {
    description: "Valiente y dispuesto a enfrentar el peligro.",
    effect: (character) => {
      character.chanceToSurvive += 10; // Aumenta la probabilidad de supervivencia
    }
  },
  cunning: {
    description: "Inteligente y astuto, capaz de engañar a otros.",
    effect: (character) => {
      character.chanceToCraft += 15; // Aumenta la probabilidad de crear herramientas
    }
  },
  compassionate: {
    description: "Empático y solidario, ayuda a otros.",
    effect: (character) => {
      character.aura.positive += 5; // Aumenta el aura positiva
    }
  },
  ruthless: {
    description: "Sin piedad, dispuesto a hacer lo que sea necesario.",
    effect: (character) => {
      character.chanceToKill += 20; // Aumenta la probabilidad de eliminar a otros
    }
  },
  resourceful: {
    description: "Capaz de encontrar soluciones creativas con recursos limitados.",
    effect: (character) => {
      character.chanceToBuild += 10; // Aumenta la probabilidad de construir refugios
    }
  },
  fearful: {
    description: "Temeroso y reacio a actuar.",
    effect: (character) => {
      character.chanceToSurvive -= 10; // Disminuye la probabilidad de supervivencia
    }
  }
};